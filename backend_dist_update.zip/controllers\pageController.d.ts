import { Request, Response } from 'express';
export declare const getPages: (req: Request, res: Response) => Promise<void>;
export declare const getPageByKey: (req: Request, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updatePage: (req: Request, res: Response) => Promise<void>;
export declare const deletePage: (req: Request, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=pageController.d.ts.map