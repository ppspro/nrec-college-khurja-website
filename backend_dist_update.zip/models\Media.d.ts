import mongoose, { Document } from 'mongoose';
export interface IMedia extends Document {
    filename: string;
    originalName: string;
    mimeType: string;
    size: number;
    url: string;
    folder: string;
    altText: string;
    width?: number;
    height?: number;
    uploadedBy?: mongoose.Types.ObjectId;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IMedia, {}, {}, {}, mongoose.Document<unknown, {}, IMedia, {}, {}> & IMedia & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Media.d.ts.map