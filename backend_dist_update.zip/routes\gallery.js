"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const galleryController_1 = require("../controllers/galleryController");
const auth_1 = require("../middleware/auth");
const upload_1 = require("../middleware/upload");
const router = (0, express_1.Router)();
router.get('/', galleryController_1.getAlbums);
router.get('/images/all', galleryController_1.getAllImages);
router.get('/admin/all', auth_1.protect, galleryController_1.getAllAlbumsAdmin);
router.get('/:slug', galleryController_1.getAlbumImages);
router.post('/albums', auth_1.protect, upload_1.upload.single('coverImage'), galleryController_1.createAlbum);
router.put('/albums/:id', auth_1.protect, upload_1.upload.single('coverImage'), galleryController_1.updateAlbum);
router.delete('/albums/:id', auth_1.protect, galleryController_1.deleteAlbum);
router.post('/images', auth_1.protect, upload_1.upload.array('images', 20), galleryController_1.addImages);
router.delete('/images/:id', auth_1.protect, galleryController_1.deleteImage);
exports.default = router;
//# sourceMappingURL=gallery.js.map