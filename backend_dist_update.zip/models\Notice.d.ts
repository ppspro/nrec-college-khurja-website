import mongoose, { Document } from 'mongoose';
export interface INotice extends Document {
    title: string;
    content: string;
    category: string;
    attachment: string;
    isPinned: boolean;
    isActive: boolean;
    expiryDate: Date | null;
    publishDate: Date;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<INotice, {}, {}, {}, mongoose.Document<unknown, {}, INotice, {}, {}> & INotice & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Notice.d.ts.map