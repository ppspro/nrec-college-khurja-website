"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.protectFaculty = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const Faculty_1 = __importDefault(require("../models/Faculty"));
const protectFaculty = async (req, res, next) => {
    try {
        let token;
        if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
            token = req.headers.authorization.split(' ')[1];
        }
        else if (req.cookies && req.cookies.facultyToken) {
            token = req.cookies.facultyToken;
        }
        if (!token) {
            res.status(401).json({ success: false, message: 'Not authorized as faculty, token missing' });
            return;
        }
        const jwtSecret = process.env.JWT_SECRET || 'secret';
        const decoded = jsonwebtoken_1.default.verify(token, jwtSecret);
        if (decoded.role && decoded.role !== 'faculty') {
            res.status(403).json({ success: false, message: 'Forbidden: Invalid token role' });
            return;
        }
        const faculty = await Faculty_1.default.findById(decoded.id).select('-password');
        if (!faculty || !faculty.isActive) {
            res.status(401).json({ success: false, message: 'Faculty account is inactive or not found' });
            return;
        }
        req.faculty = {
            id: faculty._id.toString(),
            email: faculty.email,
            departmentId: faculty.department.toString(),
            isHod: faculty.isHod || false,
        };
        next();
    }
    catch (error) {
        res.status(401).json({ success: false, message: 'Not authorized, token validation failed' });
    }
};
exports.protectFaculty = protectFaculty;
//# sourceMappingURL=facultyAuth.js.map