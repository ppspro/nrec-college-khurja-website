"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.togglePin = exports.deleteNotice = exports.updateNotice = exports.createNotice = exports.getNoticeById = exports.getNotices = void 0;
const Notice_1 = __importDefault(require("../models/Notice"));
const getNotices = async (req, res) => {
    try {
        const { search, category, page = 1, limit = 10, all } = req.query;
        const query = { isActive: true };
        // Filter out expired notices for public
        if (!all) {
            query.$or = [{ expiryDate: null }, { expiryDate: { $gt: new Date() } }];
        }
        if (search) {
            query.$and = [
                ...(query.$and || []),
                { title: { $regex: search, $options: 'i' } },
            ];
        }
        if (category && category !== 'all') {
            query.category = category;
        }
        const skip = (Number(page) - 1) * Number(limit);
        const total = await Notice_1.default.countDocuments(query);
        const notices = await Notice_1.default.find(query)
            .sort({ isPinned: -1, publishDate: -1 })
            .skip(skip)
            .limit(Number(limit));
        res.json({
            success: true,
            notices,
            pagination: {
                total,
                page: Number(page),
                pages: Math.ceil(total / Number(limit)),
                limit: Number(limit),
            },
        });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getNotices = getNotices;
const getNoticeById = async (req, res) => {
    try {
        const notice = await Notice_1.default.findById(req.params.id);
        if (!notice) {
            res.status(404).json({ success: false, message: 'Notice not found' });
            return;
        }
        res.json({ success: true, notice });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getNoticeById = getNoticeById;
const createNotice = async (req, res) => {
    try {
        const { title, content, category, isPinned, expiryDate, publishDate } = req.body;
        const attachment = req.file ? `/uploads/notices/${req.file.filename}` : '';
        const notice = await Notice_1.default.create({
            title,
            content,
            category,
            attachment,
            isPinned: isPinned === 'true' || isPinned === true,
            expiryDate: expiryDate || null,
            publishDate: publishDate || new Date(),
        });
        res.status(201).json({ success: true, notice });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.createNotice = createNotice;
const updateNotice = async (req, res) => {
    try {
        const updateData = { ...req.body };
        if (req.file) {
            updateData.attachment = `/uploads/notices/${req.file.filename}`;
        }
        const notice = await Notice_1.default.findByIdAndUpdate(req.params.id, updateData, { new: true });
        if (!notice) {
            res.status(404).json({ success: false, message: 'Notice not found' });
            return;
        }
        res.json({ success: true, notice });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.updateNotice = updateNotice;
const deleteNotice = async (req, res) => {
    try {
        const notice = await Notice_1.default.findByIdAndDelete(req.params.id);
        if (!notice) {
            res.status(404).json({ success: false, message: 'Notice not found' });
            return;
        }
        res.json({ success: true, message: 'Notice deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.deleteNotice = deleteNotice;
const togglePin = async (req, res) => {
    try {
        const notice = await Notice_1.default.findById(req.params.id);
        if (!notice) {
            res.status(404).json({ success: false, message: 'Notice not found' });
            return;
        }
        notice.isPinned = !notice.isPinned;
        await notice.save();
        res.json({ success: true, notice });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.togglePin = togglePin;
//# sourceMappingURL=noticeController.js.map