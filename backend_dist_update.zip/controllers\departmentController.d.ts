import { Request, Response } from 'express';
export declare const getDepartments: (_req: Request, res: Response) => Promise<void>;
export declare const getDepartmentBySlug: (req: Request, res: Response) => Promise<void>;
export declare const getAllDepartmentsAdmin: (_req: Request, res: Response) => Promise<void>;
export declare const createDepartment: (req: Request, res: Response) => Promise<void>;
export declare const updateDepartment: (req: Request, res: Response) => Promise<void>;
export declare const deleteDepartment: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=departmentController.d.ts.map