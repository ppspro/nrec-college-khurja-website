"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const morgan_1 = __importDefault(require("morgan"));
const path_1 = __importDefault(require("path"));
const dotenv_1 = __importDefault(require("dotenv"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
dotenv_1.default.config();
const database_1 = __importDefault(require("./config/database"));
const logger_1 = __importDefault(require("./utils/logger"));
const requestId_1 = require("./middleware/requestId");
const errorHandler_1 = require("./middleware/errorHandler");
// Version 1.0 Public & CMS Routes
const auth_1 = __importDefault(require("./routes/auth"));
const settings_1 = __importDefault(require("./routes/settings"));
const departments_1 = __importDefault(require("./routes/departments"));
const courses_1 = __importDefault(require("./routes/courses"));
const faculty_1 = __importDefault(require("./routes/faculty"));
const notices_1 = __importDefault(require("./routes/notices"));
const news_1 = __importDefault(require("./routes/news"));
const events_1 = __importDefault(require("./routes/events"));
const curriculum_1 = __importDefault(require("./routes/curriculum"));
const downloads_1 = __importDefault(require("./routes/downloads"));
const gallery_1 = __importDefault(require("./routes/gallery"));
const contact_1 = __importDefault(require("./routes/contact"));
const pages_1 = __importDefault(require("./routes/pages"));
const media_1 = __importDefault(require("./routes/media"));
const menus_1 = __importDefault(require("./routes/menus"));
const app = (0, express_1.default)();
// Connect DB
(0, database_1.default)();
// ─── Middleware ──────────────────────────────────────────────────────────────
app.use(requestId_1.requestId);
app.use((0, helmet_1.default)({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
}));
app.use((0, cors_1.default)({
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true,
}));
app.use((0, morgan_1.default)(':method :url :status :res[content-length] - :response-time ms', {
    stream: {
        write: (message) => {
            logger_1.default.info('HTTP', { access: message.trim() });
        },
    },
    skip: (_req, res) => res.statusCode < 400 && process.env.NODE_ENV === 'production',
}));
app.use(express_1.default.json({ limit: '50mb' }));
app.use(express_1.default.urlencoded({ extended: true, limit: '50mb' }));
// Global Rate Limiting
const globalLimiter = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 1000, // Limit each IP to 1000 requests per window
    message: 'Too many requests from this IP, please try again later.',
    standardHeaders: true,
    legacyHeaders: false,
});
app.use('/api', globalLimiter);
// Specific Auth Throttling
const authLimiter = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000,
    max: 20, // 20 attempts per 15 min
    message: 'Too many login attempts from this IP, please try again later.'
});
app.use('/api/auth', authLimiter);
// Static files (uploads)
app.use('/uploads', express_1.default.static(path_1.default.join(process.cwd(), 'uploads')));
// ─── Health Check ────────────────────────────────────────────────────────────
app.get('/api/health', (_req, res) => {
    res.json({
        success: true,
        status: 'healthy',
        timestamp: new Date().toISOString(),
        version: '1.0.0',
    });
});
// ─── API Routes (Version 1.0 Public & CMS) ────────────────────────────────────
app.use('/api/auth', auth_1.default);
app.use('/api/settings', settings_1.default);
app.use('/api/departments', departments_1.default);
app.use('/api/courses', courses_1.default);
app.use('/api/faculty', faculty_1.default);
app.use('/api/notices', notices_1.default);
app.use('/api/news', news_1.default);
app.use('/api/events', events_1.default);
app.use('/api/curriculum', curriculum_1.default);
app.use('/api/downloads', downloads_1.default);
app.use('/api/gallery', gallery_1.default);
app.use('/api/contact', contact_1.default);
app.use('/api/pages', pages_1.default);
app.use('/api/media', media_1.default);
app.use('/api/menus', menus_1.default);
// ─── Error Handling ──────────────────────────────────────────────────────────
app.use(errorHandler_1.notFound);
app.use(errorHandler_1.errorHandler);
// ─── Server Startup ──────────────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT || '5005', 10);
const server = app.listen(PORT, () => {
    logger_1.default.info('NREC College Website API started', {
        port: PORT,
        environment: process.env.NODE_ENV || 'development',
        version: '1.0.0',
    });
});
// ─── Graceful Shutdown ───────────────────────────────────────────────────────
const shutdown = (signal) => {
    logger_1.default.info(`${signal} received – shutting down gracefully`);
    server.close(() => {
        logger_1.default.info('HTTP server closed');
        process.exit(0);
    });
    setTimeout(() => {
        logger_1.default.error('Forced shutdown after timeout');
        process.exit(1);
    }, 10000);
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('uncaughtException', (err) => {
    logger_1.default.error('Uncaught exception – shutting down', {
        error: err.message,
        stack: err.stack,
    });
    process.exit(1);
});
process.on('unhandledRejection', (reason) => {
    logger_1.default.error('Unhandled rejection – shutting down', {
        reason: String(reason),
    });
    process.exit(1);
});
exports.default = app;
//# sourceMappingURL=index.js.map