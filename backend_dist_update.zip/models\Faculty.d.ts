import mongoose, { Document } from 'mongoose';
export interface IFaculty extends Document {
    name: string;
    designation: string;
    qualification: string;
    department: mongoose.Types.ObjectId;
    email: string;
    password?: string;
    phone: string;
    photo: string;
    avatar?: string;
    biography: string;
    specialization: string[];
    experience: string;
    publications: string[];
    order: number;
    isActive: boolean;
    isHod: boolean;
    refreshToken?: string;
    createdAt: Date;
    updatedAt: Date;
    comparePassword(candidatePassword: string): Promise<boolean>;
}
declare const _default: mongoose.Model<IFaculty, {}, {}, {}, mongoose.Document<unknown, {}, IFaculty, {}, {}> & IFaculty & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Faculty.d.ts.map