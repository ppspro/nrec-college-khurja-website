import mongoose, { Document } from 'mongoose';
export interface IDepartment extends Document {
    name: string;
    slug: string;
    shortName: string;
    description: string;
    image: string;
    icon: string;
    headOfDepartment: string;
    establishedYear: string;
    vision: string;
    mission: string;
    objectives: string[];
    facilities: string[];
    achievements: string[];
    order: number;
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IDepartment, {}, {}, {}, mongoose.Document<unknown, {}, IDepartment, {}, {}> & IDepartment & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Department.d.ts.map