"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteDepartment = exports.updateDepartment = exports.createDepartment = exports.getAllDepartmentsAdmin = exports.getDepartmentBySlug = exports.getDepartments = void 0;
const Department_1 = __importDefault(require("../models/Department"));
const slugify_1 = __importDefault(require("slugify"));
const upload_1 = require("../middleware/upload");
const getDepartments = async (_req, res) => {
    try {
        const departments = await Department_1.default.find({ isActive: true }).sort({ order: 1, name: 1 });
        res.json({ success: true, departments });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getDepartments = getDepartments;
const getDepartmentBySlug = async (req, res) => {
    try {
        const dept = await Department_1.default.findOne({ slug: req.params.slug, isActive: true });
        if (!dept) {
            res.status(404).json({ success: false, message: 'Department not found' });
            return;
        }
        res.json({ success: true, department: dept });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getDepartmentBySlug = getDepartmentBySlug;
const getAllDepartmentsAdmin = async (_req, res) => {
    try {
        const departments = await Department_1.default.find().sort({ order: 1, name: 1 });
        res.json({ success: true, departments });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getAllDepartmentsAdmin = getAllDepartmentsAdmin;
const createDepartment = async (req, res) => {
    try {
        const { name, shortName, description, headOfDepartment, establishedYear, vision, mission, objectives, facilities, achievements, order } = req.body;
        const slug = (0, slugify_1.default)(name, { lower: true, strict: true });
        let image = '';
        if (req.file) {
            image = await (0, upload_1.processImage)(req.file.buffer, 'gallery', `dept-${Date.now()}`, 800, 500);
        }
        const department = await Department_1.default.create({
            name, slug, shortName, description, image, headOfDepartment, establishedYear, vision, mission,
            objectives: objectives ? JSON.parse(objectives) : [],
            facilities: facilities ? JSON.parse(facilities) : [],
            achievements: achievements ? JSON.parse(achievements) : [],
            order: order || 0,
        });
        res.status(201).json({ success: true, department });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.createDepartment = createDepartment;
const updateDepartment = async (req, res) => {
    try {
        const updateData = { ...req.body };
        if (req.file) {
            updateData.image = await (0, upload_1.processImage)(req.file.buffer, 'gallery', `dept-${Date.now()}`, 800, 500);
        }
        ['objectives', 'facilities', 'achievements'].forEach((key) => {
            if (updateData[key] && typeof updateData[key] === 'string') {
                updateData[key] = JSON.parse(updateData[key]);
            }
        });
        const department = await Department_1.default.findByIdAndUpdate(req.params.id, updateData, { new: true });
        if (!department) {
            res.status(404).json({ success: false, message: 'Department not found' });
            return;
        }
        res.json({ success: true, department });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.updateDepartment = updateDepartment;
const deleteDepartment = async (req, res) => {
    try {
        const department = await Department_1.default.findByIdAndDelete(req.params.id);
        if (!department) {
            res.status(404).json({ success: false, message: 'Department not found' });
            return;
        }
        res.json({ success: true, message: 'Department deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.deleteDepartment = deleteDepartment;
//# sourceMappingURL=departmentController.js.map