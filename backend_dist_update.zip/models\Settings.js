"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importStar(require("mongoose"));
const settingsSchema = new mongoose_1.Schema({
    collegeName: { type: String, default: 'NREC College' },
    tagline: { type: String, default: 'Excellence in Education Since 1901' },
    logo: { type: String, default: '' },
    favicon: { type: String, default: '' },
    address: { type: String, default: 'Khurja, Uttar Pradesh, India' },
    phone: [{ type: String }],
    email: [{ type: String }],
    website: { type: String, default: '' },
    footerText: { type: String, default: '' },
    footerLinks: [{ label: String, url: String }],
    socialLinks: {
        facebook: String,
        twitter: String,
        instagram: String,
        youtube: String,
        linkedin: String,
    },
    seoTitle: { type: String, default: 'NREC College Khurja | Excellence in Education Since 1901' },
    seoDescription: { type: String, default: 'NREC College, Khurja - A premier institution of higher education in Uttar Pradesh.' },
    seoKeywords: { type: String, default: 'NREC College, Khurja, UP college, higher education' },
    googleMapEmbed: { type: String, default: '' },
    establishedYear: { type: String, default: '1901' },
    affiliatedTo: { type: String, default: 'Chaudhary Charan Singh University, Meerut' },
    recognizedBy: [{ type: String }],
    maintenanceMode: { type: Boolean, default: false },
    siteAnnouncement: { type: String, default: '' },
    analyticsId: { type: String, default: '' },
    smtpConfig: { type: mongoose_1.Schema.Types.Mixed, default: {} },
}, { timestamps: true });
exports.default = mongoose_1.default.model('Settings', settingsSchema);
//# sourceMappingURL=Settings.js.map