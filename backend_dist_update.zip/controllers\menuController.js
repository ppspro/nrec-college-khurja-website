"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateMenu = exports.getMenuByKey = exports.getMenus = void 0;
const Menu_1 = __importDefault(require("../models/Menu"));
const getMenus = async (req, res) => {
    try {
        const menus = await Menu_1.default.find();
        res.json({ success: true, menus });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};
exports.getMenus = getMenus;
const getMenuByKey = async (req, res) => {
    try {
        const menu = await Menu_1.default.findOne({ key: req.params.key });
        if (!menu)
            return res.status(404).json({ success: false, message: 'Menu not found' });
        res.json({ success: true, menu });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};
exports.getMenuByKey = getMenuByKey;
const updateMenu = async (req, res) => {
    try {
        const { name, items } = req.body;
        let menu = await Menu_1.default.findOne({ key: req.params.key });
        if (!menu) {
            menu = await Menu_1.default.create({ key: req.params.key, name, items });
        }
        else {
            if (name !== undefined)
                menu.name = name;
            if (items !== undefined)
                menu.items = items;
            await menu.save();
        }
        res.json({ success: true, menu });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};
exports.updateMenu = updateMenu;
//# sourceMappingURL=menuController.js.map