"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteNews = exports.updateNews = exports.createNews = exports.getAllNewsAdmin = exports.getNewsBySlug = exports.getNews = void 0;
const News_1 = __importDefault(require("../models/News"));
const slugify_1 = __importDefault(require("slugify"));
const upload_1 = require("../middleware/upload");
const getNews = async (req, res) => {
    try {
        const { page = 1, limit = 9, category, featured } = req.query;
        const query = { isPublished: true };
        if (category && category !== 'all')
            query.category = category;
        if (featured === 'true')
            query.isFeatured = true;
        const skip = (Number(page) - 1) * Number(limit);
        const total = await News_1.default.countDocuments(query);
        const news = await News_1.default.find(query)
            .sort({ publishDate: -1 })
            .skip(skip)
            .limit(Number(limit));
        res.json({ success: true, news, pagination: { total, page: Number(page), pages: Math.ceil(total / Number(limit)) } });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getNews = getNews;
const getNewsBySlug = async (req, res) => {
    try {
        const news = await News_1.default.findOne({ slug: req.params.slug, isPublished: true });
        if (!news) {
            res.status(404).json({ success: false, message: 'News not found' });
            return;
        }
        res.json({ success: true, news });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getNewsBySlug = getNewsBySlug;
const getAllNewsAdmin = async (_req, res) => {
    try {
        const news = await News_1.default.find().sort({ publishDate: -1 });
        res.json({ success: true, news });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getAllNewsAdmin = getAllNewsAdmin;
const createNews = async (req, res) => {
    try {
        const { title, excerpt, content, category, tags, author, publishDate, isPublished, isFeatured } = req.body;
        const slug = (0, slugify_1.default)(title, { lower: true, strict: true });
        let image = '';
        if (req.file) {
            const filename = `news-${Date.now()}`;
            image = await (0, upload_1.processImage)(req.file.buffer, 'news', filename, 800, 450);
        }
        const news = await News_1.default.create({ title, slug, excerpt, content, image, category, tags: tags ? JSON.parse(tags) : [], author, publishDate, isPublished, isFeatured });
        res.status(201).json({ success: true, news });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.createNews = createNews;
const updateNews = async (req, res) => {
    try {
        const updateData = { ...req.body };
        if (req.file) {
            const filename = `news-${Date.now()}`;
            updateData.image = await (0, upload_1.processImage)(req.file.buffer, 'news', filename, 800, 450);
        }
        if (updateData.tags && typeof updateData.tags === 'string') {
            updateData.tags = JSON.parse(updateData.tags);
        }
        const news = await News_1.default.findByIdAndUpdate(req.params.id, updateData, { new: true });
        if (!news) {
            res.status(404).json({ success: false, message: 'News not found' });
            return;
        }
        res.json({ success: true, news });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.updateNews = updateNews;
const deleteNews = async (req, res) => {
    try {
        const news = await News_1.default.findByIdAndDelete(req.params.id);
        if (!news) {
            res.status(404).json({ success: false, message: 'News not found' });
            return;
        }
        res.json({ success: true, message: 'News deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.deleteNews = deleteNews;
//# sourceMappingURL=newsController.js.map