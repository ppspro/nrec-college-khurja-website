import { Request, Response } from 'express';
export declare const getCourses: (req: Request, res: Response) => Promise<void>;
export declare const getCourseBySlug: (req: Request, res: Response) => Promise<void>;
export declare const getAllCoursesAdmin: (_req: Request, res: Response) => Promise<void>;
export declare const createCourse: (req: Request, res: Response) => Promise<void>;
export declare const updateCourse: (req: Request, res: Response) => Promise<void>;
export declare const deleteCourse: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=courseController.d.ts.map