"use strict";
/**
 * Structured JSON logger for NREC College Backend.
 *
 * Outputs one JSON object per line – compatible with any log aggregator
 * (Loki, CloudWatch, Datadog, ELK, etc.).
 *
 * Usage:
 *   import logger from '../utils/logger';
 *   logger.info('Server started', { port: 5000 });
 *   logger.error('DB error', { error: err.message });
 */
Object.defineProperty(exports, "__esModule", { value: true });
const SERVICE_NAME = 'nrec-backend';
const LEVEL_ORDER = {
    debug: 0,
    info: 1,
    warn: 2,
    error: 3,
};
function getMinLevel() {
    const env = process.env.LOG_LEVEL?.toLowerCase();
    if (env && env in LEVEL_ORDER)
        return env;
    return process.env.NODE_ENV === 'production' ? 'info' : 'debug';
}
function write(level, message, meta = {}) {
    const minLevel = getMinLevel();
    if (LEVEL_ORDER[level] < LEVEL_ORDER[minLevel])
        return;
    const entry = {
        timestamp: new Date().toISOString(),
        level,
        service: SERVICE_NAME,
        message,
        ...meta,
    };
    const line = JSON.stringify(entry);
    if (level === 'error') {
        process.stderr.write(line + '\n');
    }
    else {
        process.stdout.write(line + '\n');
    }
}
const logger = {
    debug: (message, meta) => write('debug', message, meta),
    info: (message, meta) => write('info', message, meta),
    warn: (message, meta) => write('warn', message, meta),
    error: (message, meta) => write('error', message, meta),
};
exports.default = logger;
//# sourceMappingURL=logger.js.map