"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteFile = exports.saveFile = exports.processImage = exports.upload = void 0;
const multer_1 = __importDefault(require("multer"));
const sharp_1 = __importDefault(require("sharp"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const UPLOAD_DIR = process.env.UPLOAD_DIR || 'uploads';
// Ensure directories exist
const dirs = ['logo', 'slider', 'gallery', 'faculty', 'curriculum', 'downloads', 'notices', 'news', 'pages', 'media'];
dirs.forEach((dir) => {
    const fullPath = path_1.default.join(UPLOAD_DIR, dir);
    if (!fs_1.default.existsSync(fullPath)) {
        fs_1.default.mkdirSync(fullPath, { recursive: true });
    }
});
const storage = multer_1.default.memoryStorage();
const fileFilter = (_req, file, cb) => {
    const allowedMimeTypes = [
        'image/jpeg',
        'image/png',
        'image/webp',
        'image/svg+xml',
        'image/gif',
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    ];
    if (allowedMimeTypes.includes(file.mimetype)) {
        cb(null, true);
    }
    else {
        cb(new Error(`File type ${file.mimetype} is not allowed`));
    }
};
exports.upload = (0, multer_1.default)({
    storage,
    fileFilter,
    limits: { fileSize: parseInt(process.env.MAX_FILE_SIZE || '10485760') },
});
const processImage = async (buffer, folder, filename, width = 1200, height, quality = 85) => {
    const outputDir = path_1.default.join(UPLOAD_DIR, folder);
    if (!fs_1.default.existsSync(outputDir)) {
        fs_1.default.mkdirSync(outputDir, { recursive: true });
    }
    const outputFilename = `${filename}.webp`;
    const outputPath = path_1.default.join(outputDir, outputFilename);
    let sharpInstance = (0, sharp_1.default)(buffer).resize(width, height, { fit: 'cover', withoutEnlargement: true });
    await sharpInstance.webp({ quality }).toFile(outputPath);
    return `/${UPLOAD_DIR}/${folder}/${outputFilename}`;
};
exports.processImage = processImage;
const saveFile = async (buffer, folder, originalName) => {
    const outputDir = path_1.default.join(UPLOAD_DIR, folder);
    if (!fs_1.default.existsSync(outputDir)) {
        fs_1.default.mkdirSync(outputDir, { recursive: true });
    }
    const ext = path_1.default.extname(originalName);
    const filename = `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`;
    const outputPath = path_1.default.join(outputDir, filename);
    fs_1.default.writeFileSync(outputPath, buffer);
    return `/${UPLOAD_DIR}/${folder}/${filename}`;
};
exports.saveFile = saveFile;
const deleteFile = (filePath) => {
    const fullPath = path_1.default.join(process.cwd(), filePath);
    if (fs_1.default.existsSync(fullPath)) {
        fs_1.default.unlinkSync(fullPath);
    }
};
exports.deleteFile = deleteFile;
//# sourceMappingURL=upload.js.map