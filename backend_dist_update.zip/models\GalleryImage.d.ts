import mongoose, { Document } from 'mongoose';
export interface IGalleryImage extends Document {
    album: mongoose.Types.ObjectId;
    title: string;
    description: string;
    image: string;
    thumbnail: string;
    videoUrl: string;
    order: number;
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IGalleryImage, {}, {}, {}, mongoose.Document<unknown, {}, IGalleryImage, {}, {}> & IGalleryImage & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=GalleryImage.d.ts.map