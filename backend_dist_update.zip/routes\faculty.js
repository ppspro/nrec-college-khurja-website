"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const facultyController_1 = require("../controllers/facultyController");
const auth_1 = require("../middleware/auth");
const upload_1 = require("../middleware/upload");
const router = (0, express_1.Router)();
router.get('/', facultyController_1.getFaculty);
router.get('/admin/all', auth_1.protect, facultyController_1.getAllFacultyAdmin);
router.get('/:id', facultyController_1.getFacultyById);
router.post('/', auth_1.protect, upload_1.upload.single('photo'), facultyController_1.createFaculty);
router.put('/:id', auth_1.protect, upload_1.upload.single('photo'), facultyController_1.updateFaculty);
router.delete('/:id', auth_1.protect, facultyController_1.deleteFaculty);
exports.default = router;
//# sourceMappingURL=faculty.js.map