"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteCurriculum = exports.updateCurriculum = exports.createCurriculum = exports.getAllCurriculumAdmin = exports.getCurriculum = void 0;
const Curriculum_1 = __importDefault(require("../models/Curriculum"));
const upload_1 = require("../middleware/upload");
const getCurriculum = async (req, res) => {
    try {
        const { department, course } = req.query;
        const query = { isActive: true };
        if (department)
            query.department = department;
        if (course)
            query.course = course;
        const curriculum = await Curriculum_1.default.find(query)
            .populate('department', 'name')
            .populate('course', 'name level')
            .sort({ createdAt: -1 });
        res.json({ success: true, curriculum });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getCurriculum = getCurriculum;
const getAllCurriculumAdmin = async (_req, res) => {
    try {
        const curriculum = await Curriculum_1.default.find()
            .populate('department', 'name')
            .populate('course', 'name')
            .sort({ createdAt: -1 });
        res.json({ success: true, curriculum });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getAllCurriculumAdmin = getAllCurriculumAdmin;
const createCurriculum = async (req, res) => {
    try {
        const { title, faculty, department, course, semesterYear } = req.body;
        if (!req.file) {
            res.status(400).json({ success: false, message: 'PDF file is required' });
            return;
        }
        const pdfFile = await (0, upload_1.saveFile)(req.file.buffer, 'curriculum', req.file.originalname);
        const curriculum = await Curriculum_1.default.create({ title, faculty, department, course, semesterYear, pdfFile });
        res.status(201).json({ success: true, curriculum });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.createCurriculum = createCurriculum;
const updateCurriculum = async (req, res) => {
    try {
        const updateData = { ...req.body };
        if (req.file) {
            updateData.pdfFile = await (0, upload_1.saveFile)(req.file.buffer, 'curriculum', req.file.originalname);
        }
        const curriculum = await Curriculum_1.default.findByIdAndUpdate(req.params.id, updateData, { new: true });
        if (!curriculum) {
            res.status(404).json({ success: false, message: 'Curriculum not found' });
            return;
        }
        res.json({ success: true, curriculum });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.updateCurriculum = updateCurriculum;
const deleteCurriculum = async (req, res) => {
    try {
        const curriculum = await Curriculum_1.default.findByIdAndDelete(req.params.id);
        if (!curriculum) {
            res.status(404).json({ success: false, message: 'Curriculum not found' });
            return;
        }
        res.json({ success: true, message: 'Curriculum deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.deleteCurriculum = deleteCurriculum;
//# sourceMappingURL=curriculumController.js.map