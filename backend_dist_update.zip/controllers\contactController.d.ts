import { Request, Response } from 'express';
export declare const getContact: (_req: Request, res: Response) => Promise<void>;
export declare const updateContact: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=contactController.d.ts.map