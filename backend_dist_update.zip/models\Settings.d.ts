import mongoose, { Document } from 'mongoose';
export interface ISocialLinks {
    facebook?: string;
    twitter?: string;
    instagram?: string;
    youtube?: string;
    linkedin?: string;
}
export interface ISettings extends Document {
    collegeName: string;
    tagline: string;
    logo: string;
    favicon: string;
    address: string;
    phone: string[];
    email: string[];
    website: string;
    footerText: string;
    footerLinks: {
        label: string;
        url: string;
    }[];
    socialLinks: ISocialLinks;
    seoTitle: string;
    seoDescription: string;
    seoKeywords: string;
    googleMapEmbed: string;
    establishedYear: string;
    affiliatedTo: string;
    recognizedBy: string[];
    maintenanceMode: boolean;
    siteAnnouncement: string;
    analyticsId: string;
    smtpConfig: Record<string, any>;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ISettings, {}, {}, {}, mongoose.Document<unknown, {}, ISettings, {}, {}> & ISettings & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Settings.d.ts.map