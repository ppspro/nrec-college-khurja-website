"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteFaculty = exports.updateFaculty = exports.createFaculty = exports.getAllFacultyAdmin = exports.getFacultyById = exports.getFaculty = void 0;
const Faculty_1 = __importDefault(require("../models/Faculty"));
const upload_1 = require("../middleware/upload");
const getFaculty = async (req, res) => {
    try {
        const { department } = req.query;
        const query = { isActive: true };
        if (department)
            query.department = department;
        const faculty = await Faculty_1.default.find(query).populate('department', 'name').sort({ order: 1, name: 1 });
        res.json({ success: true, faculty });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getFaculty = getFaculty;
const getFacultyById = async (req, res) => {
    try {
        const faculty = await Faculty_1.default.findById(req.params.id).populate('department', 'name');
        if (!faculty) {
            res.status(404).json({ success: false, message: 'Faculty not found' });
            return;
        }
        res.json({ success: true, faculty });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getFacultyById = getFacultyById;
const getAllFacultyAdmin = async (_req, res) => {
    try {
        const faculty = await Faculty_1.default.find().populate('department', 'name').sort({ name: 1 });
        res.json({ success: true, faculty });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getAllFacultyAdmin = getAllFacultyAdmin;
const createFaculty = async (req, res) => {
    try {
        const { name, designation, qualification, department, email, phone, biography, specialization, experience, publications, order } = req.body;
        let photo = '';
        if (req.file) {
            photo = await (0, upload_1.processImage)(req.file.buffer, 'faculty', `faculty-${Date.now()}`, 400, 400);
        }
        const faculty = await Faculty_1.default.create({
            name, designation, qualification, department, email, phone, photo, biography,
            specialization: specialization ? JSON.parse(specialization) : [],
            experience,
            publications: publications ? JSON.parse(publications) : [],
            order: order || 0,
        });
        res.status(201).json({ success: true, faculty });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.createFaculty = createFaculty;
const updateFaculty = async (req, res) => {
    try {
        const updateData = { ...req.body };
        if (req.file) {
            updateData.photo = await (0, upload_1.processImage)(req.file.buffer, 'faculty', `faculty-${Date.now()}`, 400, 400);
        }
        ['specialization', 'publications'].forEach((key) => {
            if (updateData[key] && typeof updateData[key] === 'string') {
                updateData[key] = JSON.parse(updateData[key]);
            }
        });
        const faculty = await Faculty_1.default.findByIdAndUpdate(req.params.id, updateData, { new: true });
        if (!faculty) {
            res.status(404).json({ success: false, message: 'Faculty not found' });
            return;
        }
        res.json({ success: true, faculty });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.updateFaculty = updateFaculty;
const deleteFaculty = async (req, res) => {
    try {
        const faculty = await Faculty_1.default.findByIdAndDelete(req.params.id);
        if (!faculty) {
            res.status(404).json({ success: false, message: 'Faculty not found' });
            return;
        }
        res.json({ success: true, message: 'Faculty deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.deleteFaculty = deleteFaculty;
//# sourceMappingURL=facultyController.js.map