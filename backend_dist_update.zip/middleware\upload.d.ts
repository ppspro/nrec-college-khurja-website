import multer from 'multer';
export declare const upload: multer.Multer;
export declare const processImage: (buffer: Buffer, folder: string, filename: string, width?: number, height?: number, quality?: number) => Promise<string>;
export declare const saveFile: (buffer: Buffer, folder: string, originalName: string) => Promise<string>;
export declare const deleteFile: (filePath: string) => void;
//# sourceMappingURL=upload.d.ts.map