"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteSlider = exports.updateSlider = exports.createSlider = exports.getAllSlidersAdmin = exports.getSliders = exports.upsertPage = exports.getPage = exports.updateSettings = exports.getSettings = void 0;
const Settings_1 = __importDefault(require("../models/Settings"));
const Page_1 = __importDefault(require("../models/Page"));
const Slider_1 = __importDefault(require("../models/Slider"));
const upload_1 = require("../middleware/upload");
// ========== SETTINGS ==========
const getSettings = async (_req, res) => {
    try {
        let settings = await Settings_1.default.findOne();
        if (!settings) {
            settings = await Settings_1.default.create({});
        }
        res.json({ success: true, settings });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getSettings = getSettings;
const updateSettings = async (req, res) => {
    try {
        const updateData = { ...req.body };
        if (req.files && typeof req.files === 'object') {
            const files = req.files;
            if (files.logo) {
                updateData.logo = await (0, upload_1.processImage)(files.logo[0].buffer, 'logo', `logo-${Date.now()}`, 400, 200);
            }
            if (files.favicon) {
                updateData.favicon = await (0, upload_1.processImage)(files.favicon[0].buffer, 'logo', `favicon-${Date.now()}`, 64, 64);
            }
        }
        ['phone', 'email', 'recognizedBy', 'footerLinks'].forEach((key) => {
            if (updateData[key] && typeof updateData[key] === 'string') {
                try {
                    updateData[key] = JSON.parse(updateData[key]);
                }
                catch { }
            }
        });
        if (updateData.socialLinks && typeof updateData.socialLinks === 'string') {
            try {
                updateData.socialLinks = JSON.parse(updateData.socialLinks);
            }
            catch { }
        }
        let settings = await Settings_1.default.findOne();
        if (!settings) {
            settings = await Settings_1.default.create(updateData);
        }
        else {
            settings = await Settings_1.default.findOneAndUpdate({}, updateData, { new: true });
        }
        res.json({ success: true, settings });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.updateSettings = updateSettings;
// ========== PAGES ==========
const getPage = async (req, res) => {
    try {
        const page = await Page_1.default.findOne({ key: req.params.key });
        if (!page) {
            res.status(404).json({ success: false, message: 'Page not found' });
            return;
        }
        res.json({ success: true, page });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getPage = getPage;
const upsertPage = async (req, res) => {
    try {
        const updateData = { ...req.body };
        if (req.file) {
            updateData.bannerImage = await (0, upload_1.processImage)(req.file.buffer, 'pages', `banner-${Date.now()}`, 1920, 600);
        }
        if (updateData.sections && typeof updateData.sections === 'string') {
            try {
                updateData.sections = JSON.parse(updateData.sections);
            }
            catch { }
        }
        const page = await Page_1.default.findOneAndUpdate({ key: req.params.key }, updateData, { new: true, upsert: true });
        res.json({ success: true, page });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.upsertPage = upsertPage;
// ========== SLIDERS ==========
const getSliders = async (_req, res) => {
    try {
        const sliders = await Slider_1.default.find({ isActive: true }).sort({ order: 1 });
        res.json({ success: true, sliders });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getSliders = getSliders;
const getAllSlidersAdmin = async (_req, res) => {
    try {
        const sliders = await Slider_1.default.find().sort({ order: 1 });
        res.json({ success: true, sliders });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getAllSlidersAdmin = getAllSlidersAdmin;
const createSlider = async (req, res) => {
    try {
        const { title, subtitle, description, buttonText, buttonLink, order } = req.body;
        if (!req.file) {
            res.status(400).json({ success: false, message: 'Image is required' });
            return;
        }
        const image = await (0, upload_1.processImage)(req.file.buffer, 'slider', `slide-${Date.now()}`, 1920, 800);
        const slider = await Slider_1.default.create({ title, subtitle, description, image, buttonText, buttonLink, order: order || 0 });
        res.status(201).json({ success: true, slider });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.createSlider = createSlider;
const updateSlider = async (req, res) => {
    try {
        const updateData = { ...req.body };
        if (req.file) {
            updateData.image = await (0, upload_1.processImage)(req.file.buffer, 'slider', `slide-${Date.now()}`, 1920, 800);
        }
        const slider = await Slider_1.default.findByIdAndUpdate(req.params.id, updateData, { new: true });
        if (!slider) {
            res.status(404).json({ success: false, message: 'Slider not found' });
            return;
        }
        res.json({ success: true, slider });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.updateSlider = updateSlider;
const deleteSlider = async (req, res) => {
    try {
        const slider = await Slider_1.default.findByIdAndDelete(req.params.id);
        if (!slider) {
            res.status(404).json({ success: false, message: 'Slider not found' });
            return;
        }
        res.json({ success: true, message: 'Slider deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.deleteSlider = deleteSlider;
//# sourceMappingURL=settingsController.js.map