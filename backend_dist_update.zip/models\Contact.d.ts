import mongoose, { Document } from 'mongoose';
export interface IContact extends Document {
    address: string;
    phones: string[];
    emails: string[];
    googleMapEmbed: string;
    googleMapLink: string;
    officeHours: string;
    socialLinks: {
        facebook?: string;
        twitter?: string;
        instagram?: string;
        youtube?: string;
        linkedin?: string;
    };
    updatedAt: Date;
}
declare const _default: mongoose.Model<IContact, {}, {}, {}, mongoose.Document<unknown, {}, IContact, {}, {}> & IContact & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Contact.d.ts.map