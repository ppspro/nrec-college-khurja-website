"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const eventController_1 = require("../controllers/eventController");
const auth_1 = require("../middleware/auth");
const upload_1 = require("../middleware/upload");
const router = (0, express_1.Router)();
router.get('/', eventController_1.getEvents);
router.get('/admin/all', auth_1.protect, eventController_1.getAllEventsAdmin);
router.get('/:slug', eventController_1.getEventBySlug);
router.post('/', auth_1.protect, upload_1.upload.single('image'), eventController_1.createEvent);
router.put('/:id', auth_1.protect, upload_1.upload.single('image'), eventController_1.updateEvent);
router.delete('/:id', auth_1.protect, eventController_1.deleteEvent);
exports.default = router;
//# sourceMappingURL=events.js.map