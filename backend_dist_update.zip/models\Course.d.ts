import mongoose, { Document } from 'mongoose';
export type CourseLevel = 'UG' | 'PG' | 'Diploma' | 'Certificate' | 'PhD';
export type CourseType = 'Regular' | 'Self-Finance' | 'Distance';
export interface ICourse extends Document {
    name: string;
    slug: string;
    code: string;
    department: mongoose.Types.ObjectId;
    level: CourseLevel;
    type: CourseType;
    duration: string;
    totalSeats: number;
    description: string;
    eligibility: string;
    feeStructure: string;
    syllabus: string;
    image: string;
    highlights: string[];
    careerProspects: string[];
    order: number;
    isActive: boolean;
    isFeatured: boolean;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ICourse, {}, {}, {}, mongoose.Document<unknown, {}, ICourse, {}, {}> & ICourse & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Course.d.ts.map