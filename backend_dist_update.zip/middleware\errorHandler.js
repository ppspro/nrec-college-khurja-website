"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createError = exports.notFound = exports.errorHandler = void 0;
const logger_1 = __importDefault(require("../utils/logger"));
/**
 * Global error handler.
 *
 * - Returns a consistent JSON shape for all errors.
 * - Includes requestId for log correlation.
 * - Never leaks stack traces or internal details to clients in production.
 * - Logs the full error server-side with requestId.
 */
const errorHandler = (err, req, res, _next) => {
    const statusCode = err.statusCode || 500;
    const requestId = req.requestId || 'unknown';
    // Determine client-facing message
    const isOperational = err.isOperational || statusCode < 500;
    const clientMessage = isOperational
        ? err.message || 'An error occurred'
        : 'Internal Server Error';
    // Log server-side with full detail
    logger_1.default.error('Unhandled error', {
        requestId,
        method: req.method,
        url: req.originalUrl,
        statusCode,
        error: err.message,
        stack: err.stack,
    });
    res.status(statusCode).json({
        success: false,
        message: clientMessage,
        requestId,
        ...(process.env.NODE_ENV === 'development' && {
            debug: {
                error: err.message,
                stack: err.stack,
            },
        }),
    });
};
exports.errorHandler = errorHandler;
/**
 * 404 handler – catches any route that was not matched.
 */
const notFound = (req, res, _next) => {
    const requestId = req.requestId || 'unknown';
    logger_1.default.warn('Route not found', {
        requestId,
        method: req.method,
        url: req.originalUrl,
    });
    res.status(404).json({
        success: false,
        message: `Route ${req.method} ${req.originalUrl} not found`,
        requestId,
    });
};
exports.notFound = notFound;
/**
 * Helper – creates an operational AppError with a given HTTP status code.
 * Use this in controllers for known error conditions.
 *
 * Example:
 *   throw createError(404, 'Department not found');
 */
const createError = (statusCode, message) => {
    const err = new Error(message);
    err.statusCode = statusCode;
    err.isOperational = true;
    return err;
};
exports.createError = createError;
//# sourceMappingURL=errorHandler.js.map