"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const noticeController_1 = require("../controllers/noticeController");
const auth_1 = require("../middleware/auth");
const upload_1 = require("../middleware/upload");
const router = (0, express_1.Router)();
// Public
router.get('/', noticeController_1.getNotices);
router.get('/:id', noticeController_1.getNoticeById);
// Protected (Admin)
router.post('/', auth_1.protect, upload_1.upload.single('attachment'), noticeController_1.createNotice);
router.put('/:id', auth_1.protect, upload_1.upload.single('attachment'), noticeController_1.updateNotice);
router.delete('/:id', auth_1.protect, noticeController_1.deleteNotice);
router.patch('/:id/pin', auth_1.protect, noticeController_1.togglePin);
exports.default = router;
//# sourceMappingURL=notices.js.map