"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const curriculumController_1 = require("../controllers/curriculumController");
const auth_1 = require("../middleware/auth");
const upload_1 = require("../middleware/upload");
const router = (0, express_1.Router)();
router.get('/', curriculumController_1.getCurriculum);
router.get('/admin/all', auth_1.protect, curriculumController_1.getAllCurriculumAdmin);
router.post('/', auth_1.protect, upload_1.upload.single('pdfFile'), curriculumController_1.createCurriculum);
router.put('/:id', auth_1.protect, upload_1.upload.single('pdfFile'), curriculumController_1.updateCurriculum);
router.delete('/:id', auth_1.protect, curriculumController_1.deleteCurriculum);
exports.default = router;
//# sourceMappingURL=curriculum.js.map