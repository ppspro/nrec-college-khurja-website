import mongoose, { Document } from 'mongoose';
export type DownloadCategory = 'Prospectus' | 'Academic Calendar' | 'Examination Forms' | 'NAAC Documents' | 'NIRF Documents' | 'Annual Reports' | 'Admission Forms' | 'Miscellaneous';
export interface IDownload extends Document {
    title: string;
    description: string;
    category: DownloadCategory;
    file: string;
    fileType: string;
    fileSize: string;
    isActive: boolean;
    order: number;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IDownload, {}, {}, {}, mongoose.Document<unknown, {}, IDownload, {}, {}> & IDownload & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Download.d.ts.map