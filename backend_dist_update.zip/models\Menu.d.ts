import mongoose, { Document } from 'mongoose';
export interface IMenuItem {
    _id?: string;
    label: string;
    url: string;
    target?: string;
    order: number;
    children?: IMenuItem[];
}
export interface IMenu extends Document {
    key: string;
    name: string;
    items: IMenuItem[];
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IMenu, {}, {}, {}, mongoose.Document<unknown, {}, IMenu, {}, {}> & IMenu & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Menu.d.ts.map