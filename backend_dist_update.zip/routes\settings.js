"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const settingsController_1 = require("../controllers/settingsController");
const auth_1 = require("../middleware/auth");
const upload_1 = require("../middleware/upload");
const router = (0, express_1.Router)();
// Settings
router.get('/', settingsController_1.getSettings);
router.put('/', auth_1.protect, upload_1.upload.fields([{ name: 'logo', maxCount: 1 }, { name: 'favicon', maxCount: 1 }]), settingsController_1.updateSettings);
// Pages
router.get('/pages/:key', settingsController_1.getPage);
router.put('/pages/:key', auth_1.protect, upload_1.upload.single('bannerImage'), settingsController_1.upsertPage);
// Sliders
router.get('/sliders', settingsController_1.getSliders);
router.get('/sliders/admin/all', auth_1.protect, settingsController_1.getAllSlidersAdmin);
router.post('/sliders', auth_1.protect, upload_1.upload.single('image'), settingsController_1.createSlider);
router.put('/sliders/:id', auth_1.protect, upload_1.upload.single('image'), settingsController_1.updateSlider);
router.delete('/sliders/:id', auth_1.protect, settingsController_1.deleteSlider);
exports.default = router;
//# sourceMappingURL=settings.js.map