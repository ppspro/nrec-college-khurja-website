"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const downloadController_1 = require("../controllers/downloadController");
const auth_1 = require("../middleware/auth");
const upload_1 = require("../middleware/upload");
const router = (0, express_1.Router)();
router.get('/', downloadController_1.getDownloads);
router.get('/admin/all', auth_1.protect, downloadController_1.getAllDownloadsAdmin);
router.post('/', auth_1.protect, upload_1.upload.single('file'), downloadController_1.createDownload);
router.put('/:id', auth_1.protect, upload_1.upload.single('file'), downloadController_1.updateDownload);
router.delete('/:id', auth_1.protect, downloadController_1.deleteDownload);
exports.default = router;
//# sourceMappingURL=downloads.js.map