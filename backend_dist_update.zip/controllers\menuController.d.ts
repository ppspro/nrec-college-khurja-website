import { Request, Response } from 'express';
export declare const getMenus: (req: Request, res: Response) => Promise<void>;
export declare const getMenuByKey: (req: Request, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const updateMenu: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=menuController.d.ts.map