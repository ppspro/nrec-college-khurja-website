import { Request, Response } from 'express';
export declare const getDownloads: (req: Request, res: Response) => Promise<void>;
export declare const getAllDownloadsAdmin: (_req: Request, res: Response) => Promise<void>;
export declare const createDownload: (req: Request, res: Response) => Promise<void>;
export declare const updateDownload: (req: Request, res: Response) => Promise<void>;
export declare const deleteDownload: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=downloadController.d.ts.map