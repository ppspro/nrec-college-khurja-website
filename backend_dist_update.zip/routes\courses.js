"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const courseController_1 = require("../controllers/courseController");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
router.get('/', courseController_1.getCourses);
router.get('/admin/all', auth_1.protect, courseController_1.getAllCoursesAdmin);
router.get('/:slug', courseController_1.getCourseBySlug);
router.post('/', auth_1.protect, courseController_1.createCourse);
router.put('/:id', auth_1.protect, courseController_1.updateCourse);
router.delete('/:id', auth_1.protect, courseController_1.deleteCourse);
exports.default = router;
//# sourceMappingURL=courses.js.map