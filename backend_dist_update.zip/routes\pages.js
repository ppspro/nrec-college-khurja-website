"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const pageController_1 = require("../controllers/pageController");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
router.get('/', pageController_1.getPages);
router.get('/:key', pageController_1.getPageByKey);
router.put('/:key', auth_1.protect, pageController_1.updatePage);
router.delete('/:key', auth_1.protect, pageController_1.deletePage);
exports.default = router;
//# sourceMappingURL=pages.js.map