import { Request, Response } from 'express';
export declare const getSettings: (_req: Request, res: Response) => Promise<void>;
export declare const updateSettings: (req: Request, res: Response) => Promise<void>;
export declare const getPage: (req: Request, res: Response) => Promise<void>;
export declare const upsertPage: (req: Request, res: Response) => Promise<void>;
export declare const getSliders: (_req: Request, res: Response) => Promise<void>;
export declare const getAllSlidersAdmin: (_req: Request, res: Response) => Promise<void>;
export declare const createSlider: (req: Request, res: Response) => Promise<void>;
export declare const updateSlider: (req: Request, res: Response) => Promise<void>;
export declare const deleteSlider: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=settingsController.d.ts.map