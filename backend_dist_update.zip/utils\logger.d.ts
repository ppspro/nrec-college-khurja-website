/**
 * Structured JSON logger for NREC College Backend.
 *
 * Outputs one JSON object per line – compatible with any log aggregator
 * (Loki, CloudWatch, Datadog, ELK, etc.).
 *
 * Usage:
 *   import logger from '../utils/logger';
 *   logger.info('Server started', { port: 5000 });
 *   logger.error('DB error', { error: err.message });
 */
declare const logger: {
    debug: (message: string, meta?: Record<string, unknown>) => void;
    info: (message: string, meta?: Record<string, unknown>) => void;
    warn: (message: string, meta?: Record<string, unknown>) => void;
    error: (message: string, meta?: Record<string, unknown>) => void;
};
export default logger;
//# sourceMappingURL=logger.d.ts.map