import { Request, Response } from 'express';
export declare const getNotices: (req: Request, res: Response) => Promise<void>;
export declare const getNoticeById: (req: Request, res: Response) => Promise<void>;
export declare const createNotice: (req: Request, res: Response) => Promise<void>;
export declare const updateNotice: (req: Request, res: Response) => Promise<void>;
export declare const deleteNotice: (req: Request, res: Response) => Promise<void>;
export declare const togglePin: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=noticeController.d.ts.map