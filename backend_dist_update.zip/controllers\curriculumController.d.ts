import { Request, Response } from 'express';
export declare const getCurriculum: (req: Request, res: Response) => Promise<void>;
export declare const getAllCurriculumAdmin: (_req: Request, res: Response) => Promise<void>;
export declare const createCurriculum: (req: Request, res: Response) => Promise<void>;
export declare const updateCurriculum: (req: Request, res: Response) => Promise<void>;
export declare const deleteCurriculum: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=curriculumController.d.ts.map