import { Request, Response, NextFunction } from 'express';
export interface FacultyAuthRequest extends Request {
    faculty?: {
        id: string;
        email: string;
        departmentId: string;
        isHod: boolean;
    };
}
export declare const protectFaculty: (req: FacultyAuthRequest, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=facultyAuth.d.ts.map