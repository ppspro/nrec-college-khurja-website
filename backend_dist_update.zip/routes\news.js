"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const newsController_1 = require("../controllers/newsController");
const auth_1 = require("../middleware/auth");
const upload_1 = require("../middleware/upload");
const router = (0, express_1.Router)();
router.get('/', newsController_1.getNews);
router.get('/admin/all', auth_1.protect, newsController_1.getAllNewsAdmin);
router.get('/:slug', newsController_1.getNewsBySlug);
router.post('/', auth_1.protect, upload_1.upload.single('image'), newsController_1.createNews);
router.put('/:id', auth_1.protect, upload_1.upload.single('image'), newsController_1.updateNews);
router.delete('/:id', auth_1.protect, newsController_1.deleteNews);
exports.default = router;
//# sourceMappingURL=news.js.map