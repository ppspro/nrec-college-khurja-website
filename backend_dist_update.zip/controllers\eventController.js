"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteEvent = exports.updateEvent = exports.createEvent = exports.getAllEventsAdmin = exports.getEventBySlug = exports.getEvents = void 0;
const Event_1 = __importDefault(require("../models/Event"));
const slugify_1 = __importDefault(require("slugify"));
const upload_1 = require("../middleware/upload");
const getEvents = async (req, res) => {
    try {
        const { upcoming, featured, page = 1, limit = 9 } = req.query;
        const query = { isPublished: true };
        if (upcoming === 'true')
            query.startDate = { $gte: new Date() };
        if (featured === 'true')
            query.isFeatured = true;
        const skip = (Number(page) - 1) * Number(limit);
        const total = await Event_1.default.countDocuments(query);
        const events = await Event_1.default.find(query)
            .sort({ startDate: 1 })
            .skip(skip)
            .limit(Number(limit));
        res.json({ success: true, events, pagination: { total, page: Number(page), pages: Math.ceil(total / Number(limit)) } });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getEvents = getEvents;
const getEventBySlug = async (req, res) => {
    try {
        const event = await Event_1.default.findOne({ slug: req.params.slug, isPublished: true });
        if (!event) {
            res.status(404).json({ success: false, message: 'Event not found' });
            return;
        }
        res.json({ success: true, event });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getEventBySlug = getEventBySlug;
const getAllEventsAdmin = async (_req, res) => {
    try {
        const events = await Event_1.default.find().sort({ startDate: -1 });
        res.json({ success: true, events });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getAllEventsAdmin = getAllEventsAdmin;
const createEvent = async (req, res) => {
    try {
        const { title, description, content, venue, startDate, endDate, startTime, endTime, category, registrationLink, isPublished, isFeatured } = req.body;
        const slug = (0, slugify_1.default)(title, { lower: true, strict: true });
        let image = '';
        if (req.file) {
            image = await (0, upload_1.processImage)(req.file.buffer, 'news', `event-${Date.now()}`, 800, 450);
        }
        const event = await Event_1.default.create({ title, slug, description, content, image, venue, startDate, endDate, startTime, endTime, category, registrationLink, isPublished, isFeatured });
        res.status(201).json({ success: true, event });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.createEvent = createEvent;
const updateEvent = async (req, res) => {
    try {
        const updateData = { ...req.body };
        if (req.file) {
            updateData.image = await (0, upload_1.processImage)(req.file.buffer, 'news', `event-${Date.now()}`, 800, 450);
        }
        const event = await Event_1.default.findByIdAndUpdate(req.params.id, updateData, { new: true });
        if (!event) {
            res.status(404).json({ success: false, message: 'Event not found' });
            return;
        }
        res.json({ success: true, event });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.updateEvent = updateEvent;
const deleteEvent = async (req, res) => {
    try {
        const event = await Event_1.default.findByIdAndDelete(req.params.id);
        if (!event) {
            res.status(404).json({ success: false, message: 'Event not found' });
            return;
        }
        res.json({ success: true, message: 'Event deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.deleteEvent = deleteEvent;
//# sourceMappingURL=eventController.js.map