import { Request, Response, NextFunction } from 'express';
export interface AppError extends Error {
    statusCode?: number;
    isOperational?: boolean;
}
/**
 * Global error handler.
 *
 * - Returns a consistent JSON shape for all errors.
 * - Includes requestId for log correlation.
 * - Never leaks stack traces or internal details to clients in production.
 * - Logs the full error server-side with requestId.
 */
export declare const errorHandler: (err: AppError, req: Request, res: Response, _next: NextFunction) => void;
/**
 * 404 handler – catches any route that was not matched.
 */
export declare const notFound: (req: Request, res: Response, _next: NextFunction) => void;
/**
 * Helper – creates an operational AppError with a given HTTP status code.
 * Use this in controllers for known error conditions.
 *
 * Example:
 *   throw createError(404, 'Department not found');
 */
export declare const createError: (statusCode: number, message: string) => AppError;
//# sourceMappingURL=errorHandler.d.ts.map