"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const contactController_1 = require("../controllers/contactController");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
router.get('/', contactController_1.getContact);
router.put('/', auth_1.protect, contactController_1.updateContact);
exports.default = router;
//# sourceMappingURL=contact.js.map