"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const menuController_1 = require("../controllers/menuController");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
router.get('/', menuController_1.getMenus);
router.get('/:key', menuController_1.getMenuByKey);
router.put('/:key', auth_1.protect, menuController_1.updateMenu);
exports.default = router;
//# sourceMappingURL=menus.js.map