"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importDefault(require("mongoose"));
const logger_1 = __importDefault(require("../utils/logger"));
const connectDB = async () => {
    try {
        const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/nrec_college';
        mongoose_1.default.connection.on('connected', () => {
            logger_1.default.info('MongoDB connected', { host: mongoose_1.default.connection.host });
        });
        mongoose_1.default.connection.on('disconnected', () => {
            logger_1.default.warn('MongoDB disconnected');
        });
        mongoose_1.default.connection.on('error', (err) => {
            logger_1.default.error('MongoDB connection error', { error: err.message });
        });
        await mongoose_1.default.connect(mongoURI, {
            // Log slow queries (>100ms) to the structured logger
            serverSelectionTimeoutMS: 5000,
        });
    }
    catch (error) {
        logger_1.default.error('Failed to connect to MongoDB – exiting', {
            error: error.message,
        });
        process.exit(1);
    }
};
exports.default = connectDB;
//# sourceMappingURL=database.js.map