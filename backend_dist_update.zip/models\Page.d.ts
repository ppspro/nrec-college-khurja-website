import mongoose, { Document } from 'mongoose';
export interface IPage extends Document {
    key: string;
    title: string;
    bannerImage: string;
    bannerTitle: string;
    bannerSubtitle: string;
    sections: any[];
    seoTitle: string;
    seoDescription: string;
    seoKeywords: string;
    ogImage: string;
    twitterCard: string;
    canonicalUrl: string;
    schemaJson: string;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IPage, {}, {}, {}, mongoose.Document<unknown, {}, IPage, {}, {}> & IPage & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Page.d.ts.map