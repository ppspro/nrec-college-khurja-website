"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const departmentController_1 = require("../controllers/departmentController");
const auth_1 = require("../middleware/auth");
const upload_1 = require("../middleware/upload");
const router = (0, express_1.Router)();
router.get('/', departmentController_1.getDepartments);
router.get('/admin/all', auth_1.protect, departmentController_1.getAllDepartmentsAdmin);
router.get('/:slug', departmentController_1.getDepartmentBySlug);
router.post('/', auth_1.protect, upload_1.upload.single('image'), departmentController_1.createDepartment);
router.put('/:id', auth_1.protect, upload_1.upload.single('image'), departmentController_1.updateDepartment);
router.delete('/:id', auth_1.protect, departmentController_1.deleteDepartment);
exports.default = router;
//# sourceMappingURL=departments.js.map