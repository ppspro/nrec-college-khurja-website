"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deletePage = exports.updatePage = exports.getPageByKey = exports.getPages = void 0;
const Page_1 = __importDefault(require("../models/Page"));
const getPages = async (req, res) => {
    try {
        const pages = await Page_1.default.find().sort({ createdAt: -1 });
        res.json({ success: true, pages });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server Error' });
    }
};
exports.getPages = getPages;
const getPageByKey = async (req, res) => {
    try {
        const page = await Page_1.default.findOne({ key: req.params.key });
        if (!page) {
            return res.status(404).json({ success: false, message: 'Page not found' });
        }
        res.json({ success: true, page });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server Error' });
    }
};
exports.getPageByKey = getPageByKey;
const updatePage = async (req, res) => {
    try {
        const { title, bannerImage, bannerTitle, bannerSubtitle, sections, seoTitle, seoDescription, seoKeywords, ogImage, twitterCard, canonicalUrl, schemaJson } = req.body;
        let page = await Page_1.default.findOne({ key: req.params.key });
        if (!page) {
            page = await Page_1.default.create({
                key: req.params.key,
                title: title || req.params.key,
                bannerImage, bannerTitle, bannerSubtitle, sections, seoTitle, seoDescription, seoKeywords, ogImage, twitterCard, canonicalUrl, schemaJson
            });
        }
        else {
            if (title !== undefined)
                page.title = title;
            if (bannerImage !== undefined)
                page.bannerImage = bannerImage;
            if (bannerTitle !== undefined)
                page.bannerTitle = bannerTitle;
            if (bannerSubtitle !== undefined)
                page.bannerSubtitle = bannerSubtitle;
            if (sections !== undefined)
                page.sections = sections; // Array assignment
            if (seoTitle !== undefined)
                page.seoTitle = seoTitle;
            if (seoDescription !== undefined)
                page.seoDescription = seoDescription;
            if (seoKeywords !== undefined)
                page.seoKeywords = seoKeywords;
            if (ogImage !== undefined)
                page.ogImage = ogImage;
            if (twitterCard !== undefined)
                page.twitterCard = twitterCard;
            if (canonicalUrl !== undefined)
                page.canonicalUrl = canonicalUrl;
            if (schemaJson !== undefined)
                page.schemaJson = schemaJson;
            await page.save();
        }
        res.json({ success: true, page });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server Error' });
    }
};
exports.updatePage = updatePage;
const deletePage = async (req, res) => {
    try {
        const page = await Page_1.default.findOneAndDelete({ key: req.params.key });
        if (!page)
            return res.status(404).json({ success: false, message: 'Page not found' });
        res.json({ success: true, message: 'Page deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server Error' });
    }
};
exports.deletePage = deletePage;
//# sourceMappingURL=pageController.js.map