"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteImage = exports.addImages = exports.deleteAlbum = exports.updateAlbum = exports.createAlbum = exports.getAllAlbumsAdmin = exports.getAlbumImages = exports.getAllImages = exports.getAlbums = void 0;
const GalleryAlbum_1 = __importDefault(require("../models/GalleryAlbum"));
const GalleryImage_1 = __importDefault(require("../models/GalleryImage"));
const slugify_1 = __importDefault(require("slugify"));
const upload_1 = require("../middleware/upload");
const getAlbums = async (_req, res) => {
    try {
        const albums = await GalleryAlbum_1.default.find({ isActive: true }).sort({ order: 1, createdAt: -1 });
        res.json({ success: true, albums });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getAlbums = getAlbums;
const getAllImages = async (_req, res) => {
    try {
        const images = await GalleryImage_1.default.find({ isActive: true }).sort({ createdAt: -1 });
        res.json({ success: true, images });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getAllImages = getAllImages;
const getAlbumImages = async (req, res) => {
    try {
        const album = await GalleryAlbum_1.default.findOne({ slug: req.params.slug, isActive: true });
        if (!album) {
            res.status(404).json({ success: false, message: 'Album not found' });
            return;
        }
        const images = await GalleryImage_1.default.find({ album: album._id, isActive: true }).sort({ order: 1 });
        res.json({ success: true, album, images });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getAlbumImages = getAlbumImages;
const getAllAlbumsAdmin = async (_req, res) => {
    try {
        const albums = await GalleryAlbum_1.default.find().sort({ order: 1 });
        res.json({ success: true, albums });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getAllAlbumsAdmin = getAllAlbumsAdmin;
const createAlbum = async (req, res) => {
    try {
        const { title, description, type, order } = req.body;
        const slug = (0, slugify_1.default)(title, { lower: true, strict: true });
        let coverImage = '';
        if (req.file) {
            coverImage = await (0, upload_1.processImage)(req.file.buffer, 'gallery', `album-${Date.now()}`, 800, 600);
        }
        const album = await GalleryAlbum_1.default.create({ title, slug, description, coverImage, type, order: order || 0 });
        res.status(201).json({ success: true, album });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.createAlbum = createAlbum;
const updateAlbum = async (req, res) => {
    try {
        const updateData = { ...req.body };
        if (req.file) {
            updateData.coverImage = await (0, upload_1.processImage)(req.file.buffer, 'gallery', `album-${Date.now()}`, 800, 600);
        }
        const album = await GalleryAlbum_1.default.findByIdAndUpdate(req.params.id, updateData, { new: true });
        if (!album) {
            res.status(404).json({ success: false, message: 'Album not found' });
            return;
        }
        res.json({ success: true, album });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.updateAlbum = updateAlbum;
const deleteAlbum = async (req, res) => {
    try {
        await GalleryImage_1.default.deleteMany({ album: req.params.id });
        const album = await GalleryAlbum_1.default.findByIdAndDelete(req.params.id);
        if (!album) {
            res.status(404).json({ success: false, message: 'Album not found' });
            return;
        }
        res.json({ success: true, message: 'Album and images deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.deleteAlbum = deleteAlbum;
const addImages = async (req, res) => {
    try {
        const { albumId, title, description, videoUrl, order } = req.body;
        const files = req.files;
        if (videoUrl) {
            const img = await GalleryImage_1.default.create({ album: albumId, title, description, videoUrl, order: order || 0 });
            res.status(201).json({ success: true, image: img });
            return;
        }
        if (!files || files.length === 0) {
            res.status(400).json({ success: false, message: 'No files uploaded' });
            return;
        }
        const images = await Promise.all(files.map(async (file, i) => {
            const image = await (0, upload_1.processImage)(file.buffer, 'gallery', `img-${Date.now()}-${i}`, 1200, 800);
            const thumbnail = await (0, upload_1.processImage)(file.buffer, 'gallery', `thumb-${Date.now()}-${i}`, 400, 300);
            return GalleryImage_1.default.create({ album: albumId, title, description, image, thumbnail, order: (order || 0) + i });
        }));
        res.status(201).json({ success: true, images });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.addImages = addImages;
const deleteImage = async (req, res) => {
    try {
        const image = await GalleryImage_1.default.findByIdAndDelete(req.params.id);
        if (!image) {
            res.status(404).json({ success: false, message: 'Image not found' });
            return;
        }
        res.json({ success: true, message: 'Image deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.deleteImage = deleteImage;
//# sourceMappingURL=galleryController.js.map