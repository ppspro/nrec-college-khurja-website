import mongoose, { Document } from 'mongoose';
export interface IGalleryAlbum extends Document {
    title: string;
    slug: string;
    description: string;
    coverImage: string;
    type: 'photo' | 'video';
    isActive: boolean;
    order: number;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IGalleryAlbum, {}, {}, {}, mongoose.Document<unknown, {}, IGalleryAlbum, {}, {}> & IGalleryAlbum & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=GalleryAlbum.d.ts.map