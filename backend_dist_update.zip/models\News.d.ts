import mongoose, { Document } from 'mongoose';
export interface INews extends Document {
    title: string;
    slug: string;
    excerpt: string;
    content: string;
    image: string;
    category: string;
    tags: string[];
    isPublished: boolean;
    isFeatured: boolean;
    publishDate: Date;
    author: string;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<INews, {}, {}, {}, mongoose.Document<unknown, {}, INews, {}, {}> & INews & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=News.d.ts.map