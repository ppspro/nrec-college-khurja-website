import mongoose, { Document } from 'mongoose';
export interface ICurriculum extends Document {
    title: string;
    faculty: string;
    department: mongoose.Types.ObjectId;
    course: mongoose.Types.ObjectId;
    semesterYear: string;
    pdfFile: string;
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ICurriculum, {}, {}, {}, mongoose.Document<unknown, {}, ICurriculum, {}, {}> & ICurriculum & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Curriculum.d.ts.map