"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeMedia = exports.getMedia = exports.uploadMedia = void 0;
const Media_1 = __importDefault(require("../models/Media"));
const upload_1 = require("../middleware/upload");
// Upload single or multiple files
const uploadMedia = async (req, res) => {
    try {
        const files = req.files;
        const folder = req.body.folder || 'media';
        const uploadedBy = req.admin?.id; // Assuming auth middleware attaches admin to req
        if (!files || files.length === 0) {
            return res.status(400).json({ success: false, message: 'No files uploaded' });
        }
        const mediaDocs = [];
        for (const file of files) {
            const isImage = file.mimetype.startsWith('image/') && !file.mimetype.includes('svg');
            let url = '';
            const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
            const filenameBase = file.originalname.replace(/[^a-zA-Z0-9]/g, '-').substring(0, 50);
            const outputFilename = `${filenameBase}-${uniqueSuffix}`;
            if (isImage) {
                url = await (0, upload_1.processImage)(file.buffer, folder, outputFilename);
            }
            else {
                url = await (0, upload_1.saveFile)(file.buffer, folder, file.originalname);
            }
            const media = await Media_1.default.create({
                filename: outputFilename,
                originalName: file.originalname,
                mimeType: file.mimetype,
                size: file.size,
                url,
                folder,
                uploadedBy
            });
            mediaDocs.push(media);
        }
        res.status(201).json({ success: true, media: mediaDocs });
    }
    catch (error) {
        console.error('Media upload error:', error);
        res.status(500).json({ success: false, message: 'Failed to upload media', error: error.message });
    }
};
exports.uploadMedia = uploadMedia;
// Get all media with pagination, filtering, search
const getMedia = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 50;
        const skip = (page - 1) * limit;
        const filter = {};
        if (req.query.folder && req.query.folder !== 'all') {
            filter.folder = req.query.folder;
        }
        if (req.query.search) {
            filter.originalName = { $regex: req.query.search, $options: 'i' };
        }
        if (req.query.type) {
            if (req.query.type === 'image')
                filter.mimeType = { $regex: /^image\// };
            if (req.query.type === 'document')
                filter.mimeType = { $not: { $regex: /^image\// } };
        }
        const total = await Media_1.default.countDocuments(filter);
        const media = await Media_1.default.find(filter)
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit)
            .populate('uploadedBy', 'name email');
        res.json({
            success: true,
            media,
            pagination: {
                total,
                page,
                pages: Math.ceil(total / limit)
            }
        });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};
exports.getMedia = getMedia;
// Delete media
const removeMedia = async (req, res) => {
    try {
        const media = await Media_1.default.findById(req.params.id);
        if (!media) {
            return res.status(404).json({ success: false, message: 'Media not found' });
        }
        // Delete file from disk
        const relativePath = media.url.startsWith('/') ? media.url.substring(1) : media.url;
        (0, upload_1.deleteFile)(relativePath);
        await media.deleteOne();
        res.json({ success: true, message: 'Media deleted successfully' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
};
exports.removeMedia = removeMedia;
//# sourceMappingURL=mediaController.js.map