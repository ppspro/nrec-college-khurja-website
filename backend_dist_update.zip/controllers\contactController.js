"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateContact = exports.getContact = void 0;
const Contact_1 = __importDefault(require("../models/Contact"));
const getContact = async (_req, res) => {
    try {
        let contact = await Contact_1.default.findOne();
        if (!contact)
            contact = await Contact_1.default.create({});
        res.json({ success: true, contact });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getContact = getContact;
const updateContact = async (req, res) => {
    try {
        const updateData = { ...req.body };
        ['phones', 'emails'].forEach((key) => {
            if (updateData[key] && typeof updateData[key] === 'string') {
                try {
                    updateData[key] = JSON.parse(updateData[key]);
                }
                catch { }
            }
        });
        if (updateData.socialLinks && typeof updateData.socialLinks === 'string') {
            try {
                updateData.socialLinks = JSON.parse(updateData.socialLinks);
            }
            catch { }
        }
        let contact = await Contact_1.default.findOne();
        if (!contact) {
            contact = await Contact_1.default.create(updateData);
        }
        else {
            contact = await Contact_1.default.findOneAndUpdate({}, updateData, { new: true });
        }
        res.json({ success: true, contact });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.updateContact = updateContact;
//# sourceMappingURL=contactController.js.map