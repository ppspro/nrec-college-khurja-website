"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteDownload = exports.updateDownload = exports.createDownload = exports.getAllDownloadsAdmin = exports.getDownloads = void 0;
const Download_1 = __importDefault(require("../models/Download"));
const upload_1 = require("../middleware/upload");
const path_1 = __importDefault(require("path"));
const getDownloads = async (req, res) => {
    try {
        const { category } = req.query;
        const query = { isActive: true };
        if (category && category !== 'all')
            query.category = category;
        const downloads = await Download_1.default.find(query).sort({ order: 1, createdAt: -1 });
        res.json({ success: true, downloads });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getDownloads = getDownloads;
const getAllDownloadsAdmin = async (_req, res) => {
    try {
        const downloads = await Download_1.default.find().sort({ category: 1, order: 1 });
        res.json({ success: true, downloads });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getAllDownloadsAdmin = getAllDownloadsAdmin;
const createDownload = async (req, res) => {
    try {
        const { title, description, category, order } = req.body;
        if (!req.file) {
            res.status(400).json({ success: false, message: 'File is required' });
            return;
        }
        const file = await (0, upload_1.saveFile)(req.file.buffer, 'downloads', req.file.originalname);
        const fileType = path_1.default.extname(req.file.originalname).replace('.', '').toUpperCase();
        const fileSize = `${(req.file.size / 1024).toFixed(1)} KB`;
        const download = await Download_1.default.create({ title, description, category, file, fileType, fileSize, order: order || 0 });
        res.status(201).json({ success: true, download });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.createDownload = createDownload;
const updateDownload = async (req, res) => {
    try {
        const updateData = { ...req.body };
        if (req.file) {
            updateData.file = await (0, upload_1.saveFile)(req.file.buffer, 'downloads', req.file.originalname);
            updateData.fileType = path_1.default.extname(req.file.originalname).replace('.', '').toUpperCase();
            updateData.fileSize = `${(req.file.size / 1024).toFixed(1)} KB`;
        }
        const download = await Download_1.default.findByIdAndUpdate(req.params.id, updateData, { new: true });
        if (!download) {
            res.status(404).json({ success: false, message: 'Download not found' });
            return;
        }
        res.json({ success: true, download });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.updateDownload = updateDownload;
const deleteDownload = async (req, res) => {
    try {
        const download = await Download_1.default.findByIdAndDelete(req.params.id);
        if (!download) {
            res.status(404).json({ success: false, message: 'Download not found' });
            return;
        }
        res.json({ success: true, message: 'Download deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.deleteDownload = deleteDownload;
//# sourceMappingURL=downloadController.js.map