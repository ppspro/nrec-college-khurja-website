import { Request, Response } from 'express';
export declare const getEvents: (req: Request, res: Response) => Promise<void>;
export declare const getEventBySlug: (req: Request, res: Response) => Promise<void>;
export declare const getAllEventsAdmin: (_req: Request, res: Response) => Promise<void>;
export declare const createEvent: (req: Request, res: Response) => Promise<void>;
export declare const updateEvent: (req: Request, res: Response) => Promise<void>;
export declare const deleteEvent: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=eventController.d.ts.map