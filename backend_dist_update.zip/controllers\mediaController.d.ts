import { Request, Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare const uploadMedia: (req: AuthRequest, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
export declare const getMedia: (req: Request, res: Response) => Promise<void>;
export declare const removeMedia: (req: Request, res: Response) => Promise<Response<any, Record<string, any>> | undefined>;
//# sourceMappingURL=mediaController.d.ts.map