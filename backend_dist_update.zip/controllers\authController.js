"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.forgotPassword = exports.changePassword = exports.updateProfile = exports.getProfile = exports.login = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const Admin_1 = __importDefault(require("../models/Admin"));
const generateToken = (id, email) => {
    return jsonwebtoken_1.default.sign({ id, email }, process.env.JWT_SECRET || 'secret', {
        expiresIn: process.env.JWT_EXPIRES_IN || '7d',
    });
};
const login = async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            res.status(400).json({ success: false, message: 'Please provide email and password' });
            return;
        }
        const admin = await Admin_1.default.findOne({ email });
        if (!admin || !(await admin.comparePassword(password))) {
            res.status(401).json({ success: false, message: 'Invalid email or password' });
            return;
        }
        const token = generateToken(admin._id.toString(), admin.email);
        res.json({
            success: true,
            token,
            admin: {
                id: admin._id,
                name: admin.name,
                email: admin.email,
                avatar: admin.avatar,
            },
        });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.login = login;
const getProfile = async (req, res) => {
    try {
        const admin = await Admin_1.default.findById(req.admin?.id).select('-password');
        if (!admin) {
            res.status(404).json({ success: false, message: 'Admin not found' });
            return;
        }
        res.json({ success: true, admin });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getProfile = getProfile;
const updateProfile = async (req, res) => {
    try {
        const { name, email } = req.body;
        const admin = await Admin_1.default.findByIdAndUpdate(req.admin?.id, { name, email }, { new: true, runValidators: true }).select('-password');
        res.json({ success: true, admin });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.updateProfile = updateProfile;
const changePassword = async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;
        const admin = await Admin_1.default.findById(req.admin?.id);
        if (!admin) {
            res.status(404).json({ success: false, message: 'Admin not found' });
            return;
        }
        const isMatch = await admin.comparePassword(currentPassword);
        if (!isMatch) {
            res.status(400).json({ success: false, message: 'Current password is incorrect' });
            return;
        }
        admin.password = newPassword;
        await admin.save();
        res.json({ success: true, message: 'Password changed successfully' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.changePassword = changePassword;
const forgotPassword = async (req, res) => {
    try {
        const { email } = req.body;
        const admin = await Admin_1.default.findOne({ email });
        if (!admin) {
            res.status(404).json({ success: false, message: 'No admin found with that email' });
            return;
        }
        // In a real app, send email. For now, return a reset token.
        const resetToken = jsonwebtoken_1.default.sign({ id: admin._id }, process.env.JWT_SECRET + '_reset' || 'reset_secret', {
            expiresIn: '1h',
        });
        res.json({
            success: true,
            message: 'Password reset token generated',
            resetToken, // In production, send this via email
        });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.forgotPassword = forgotPassword;
//# sourceMappingURL=authController.js.map