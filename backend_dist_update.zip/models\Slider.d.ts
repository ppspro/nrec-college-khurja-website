import mongoose, { Document } from 'mongoose';
export interface ISlider extends Document {
    title: string;
    subtitle: string;
    description: string;
    image: string;
    buttonText: string;
    buttonLink: string;
    order: number;
    isActive: boolean;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<ISlider, {}, {}, {}, mongoose.Document<unknown, {}, ISlider, {}, {}> & ISlider & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Slider.d.ts.map