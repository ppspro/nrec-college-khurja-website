import { Request, Response } from 'express';
export declare const getAlbums: (_req: Request, res: Response) => Promise<void>;
export declare const getAllImages: (_req: Request, res: Response) => Promise<void>;
export declare const getAlbumImages: (req: Request, res: Response) => Promise<void>;
export declare const getAllAlbumsAdmin: (_req: Request, res: Response) => Promise<void>;
export declare const createAlbum: (req: Request, res: Response) => Promise<void>;
export declare const updateAlbum: (req: Request, res: Response) => Promise<void>;
export declare const deleteAlbum: (req: Request, res: Response) => Promise<void>;
export declare const addImages: (req: Request, res: Response) => Promise<void>;
export declare const deleteImage: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=galleryController.d.ts.map