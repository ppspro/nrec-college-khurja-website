"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const mongoose_1 = __importDefault(require("mongoose"));
const Admin_1 = __importDefault(require("../models/Admin"));
const Settings_1 = __importDefault(require("../models/Settings"));
const Contact_1 = __importDefault(require("../models/Contact"));
const Department_1 = __importDefault(require("../models/Department"));
const Course_1 = __importDefault(require("../models/Course"));
const Faculty_1 = __importDefault(require("../models/Faculty"));
const Slider_1 = __importDefault(require("../models/Slider"));
const Notice_1 = __importDefault(require("../models/Notice"));
const Event_1 = __importDefault(require("../models/Event"));
const Download_1 = __importDefault(require("../models/Download"));
const Curriculum_1 = __importDefault(require("../models/Curriculum"));
const GalleryAlbum_1 = __importDefault(require("../models/GalleryAlbum"));
const GalleryImage_1 = __importDefault(require("../models/GalleryImage"));
const Page_1 = __importDefault(require("../models/Page"));
const seed = async () => {
    try {
        await mongoose_1.default.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/nrec_college');
        console.log('✅ Connected to MongoDB');
        // 1. Create Admin
        let admin = await Admin_1.default.findOne({ email: 'admin@nreccollege.ac.in' });
        if (!admin) {
            admin = await Admin_1.default.create({
                name: 'NREC Admin',
                email: 'admin@nreccollege.ac.in',
                password: 'admin@123',
            });
            console.log('✅ Admin created: admin@nreccollege.ac.in / admin@123');
        }
        // 2. Settings & Contact
        if (!(await Settings_1.default.findOne())) {
            await Settings_1.default.create({
                collegeName: 'NREC College',
                tagline: 'Excellence in Education Since 1901',
                address: 'Khurja, Bulandshahr District, Uttar Pradesh - 203131',
                phone: ['+91-5738-200001', '+91-5738-200002'],
                email: ['principal@nreccollege.ac.in', 'info@nreccollege.ac.in'],
                establishedYear: '1901',
                affiliatedTo: 'Chaudhary Charan Singh University, Meerut',
                recognizedBy: ['UGC', 'NAAC'],
            });
            console.log('✅ Settings initialized');
        }
        if (!(await Contact_1.default.findOne())) {
            await Contact_1.default.create({
                address: 'NREC College, Khurja, Bulandshahr District, Uttar Pradesh - 203131',
                phones: ['+91-5738-200001'],
                emails: ['principal@nreccollege.ac.in', 'info@nreccollege.ac.in'],
            });
            console.log('✅ Contact info initialized');
        }
        // 3. Sliders
        if ((await Slider_1.default.countDocuments()) === 0) {
            await Slider_1.default.create([
                {
                    title: 'Welcome to NREC College',
                    subtitle: 'Empowering minds and enriching lives since 1901',
                    image: 'https://images.unsplash.com/photo-1541829070764-84a7d30dd3f3?auto=format&fit=crop&w=1200&q=80',
                    linkText: 'Explore Courses',
                    linkUrl: '/courses',
                    order: 1,
                    isActive: true
                },
                {
                    title: 'State of the Art Laboratories',
                    subtitle: 'Fostering research and technological innovation',
                    image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=1200&q=80',
                    linkText: 'Discover Departments',
                    linkUrl: '/departments',
                    order: 2,
                    isActive: true
                }
            ]);
            console.log('✅ Hero sliders created');
        }
        // 4. Department & Course
        let dept = await Department_1.default.findOne({ $or: [{ code: 'CS' }, { slug: 'computer-science' }] });
        if (!dept) {
            dept = await Department_1.default.create({
                name: 'Computer Science & IT',
                slug: 'computer-science',
                code: 'CS',
                description: 'Department of Computer Science and Information Technology providing top tier computing education.',
                hodName: 'Dr. Rajesh Sharma',
                facilities: ['High-speed Wi-Fi', 'AI Research Lab', 'Cloud Computing Server Room'],
                laboratories: ['Software Engineering Lab', 'Networking Lab']
            });
            console.log('✅ Department created: Computer Science');
        }
        let course = await Course_1.default.findOne({ $or: [{ code: 'BCA' }, { slug: 'bca' }] });
        if (!course) {
            course = await Course_1.default.create({
                name: 'Bachelor of Computer Applications',
                slug: 'bca',
                code: 'BCA',
                department: dept._id,
                duration: '3 Years (6 Semesters)',
                eligibility: '10+2 with Mathematics or Computer Applications',
                description: 'Comprehensive undergraduate program focusing on modern software development and computer systems.'
            });
            console.log('✅ Course created: BCA');
        }
        // 5. Faculty
        let faculty = await Faculty_1.default.findOne({ email: 'dr.sharma@nreccollege.ac.in' });
        if (!faculty) {
            faculty = await Faculty_1.default.create({
                name: 'Dr. Rajesh Sharma',
                email: 'dr.sharma@nreccollege.ac.in',
                designation: 'Head of Department',
                qualification: 'Ph.D in Computer Science',
                department: dept._id,
                specialization: ['Database Systems', 'Software Engineering'],
                image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'
            });
            console.log('✅ Faculty created: Dr. Rajesh Sharma');
        }
        // 6. Notices
        if ((await Notice_1.default.countDocuments()) === 0) {
            await Notice_1.default.create([
                {
                    title: 'Annual Academic Calendar 2026-2027 Released',
                    category: 'Academic',
                    content: 'The official academic calendar for the upcoming session has been published. Please download the document below for details.',
                    isPinned: true,
                    publishDate: new Date(),
                    attachment: '/uploads/sample_academic_calendar.pdf'
                },
                {
                    title: 'Campus Administrative Guidelines Updated',
                    category: 'Administrative',
                    content: 'Updated campus guidelines and administrative schedule have been issued for all faculty and staff.',
                    isPinned: false,
                    publishDate: new Date()
                }
            ]);
            console.log('✅ Notices created');
        }
        // 7. Events
        if ((await Event_1.default.countDocuments()) === 0) {
            await Event_1.default.create([
                {
                    title: 'National Conference on Advances in Computing (NCAC 2026)',
                    slug: 'national-conference-advances-computing-2026',
                    description: 'Join industry experts and researchers for a two-day conference on AI, Quantum Computing, and Cybersecurity.',
                    startDate: new Date(Date.now() + 86400000 * 7),
                    endDate: new Date(Date.now() + 86400000 * 9),
                    location: 'Main College Auditorium',
                    coverImage: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80',
                    isFeatured: true
                }
            ]);
            console.log('✅ Events created');
        }
        // 8. Gallery Albums & Images
        if ((await GalleryAlbum_1.default.countDocuments()) === 0) {
            const album = await GalleryAlbum_1.default.create({
                title: 'Annual Sports Meet 2026',
                slug: 'annual-sports-meet-2026',
                description: 'Highlights from the inter-college athletics tournament.',
                coverImage: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=800&q=80'
            });
            await GalleryImage_1.default.create([
                {
                    album: album._id,
                    title: '100m Sprint Final',
                    url: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=800&q=80'
                },
                {
                    album: album._id,
                    title: 'Basketball Championship Ceremony',
                    url: 'https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=800&q=80'
                }
            ]);
            console.log('✅ Gallery album and images created');
        }
        // 9. Downloads
        if ((await Download_1.default.countDocuments()) === 0) {
            await Download_1.default.create([
                {
                    title: 'College Prospectus 2026',
                    category: 'Prospectus',
                    description: 'Complete guide to courses, admissions, and facilities at NREC College.',
                    file: '/uploads/sample_prospectus.pdf',
                    fileType: 'PDF',
                    fileSize: '2.4 MB'
                }
            ]);
            console.log('✅ Downloads created');
        }
        // 10. Curriculum
        if ((await Curriculum_1.default.countDocuments()) === 0) {
            await Curriculum_1.default.create([
                {
                    title: 'BCA Semester 1 Syllabus',
                    faculty: 'Computer Science',
                    department: dept._id,
                    course: course._id,
                    semesterYear: 'Semester 1',
                    pdfFile: '/uploads/bca_sem1_syllabus.pdf'
                }
            ]);
            console.log('✅ Curriculum created');
        }
        // 11. Create Default Home Page
        let homePage = await Page_1.default.findOne({ key: 'home' });
        if (!homePage) {
            await Page_1.default.create({
                key: 'home',
                title: 'Home',
                sections: {
                    welcome: {
                        title: 'Welcome to NREC College',
                        subtitle: 'A Legacy of Excellence since 1901',
                        paragraphs: [
                            'NREC College, Khurja is one of the oldest and most prestigious institutions of higher learning in Uttar Pradesh. Established in 1901, the college has been a beacon of academic excellence, catering to the educational needs of the region.',
                            'With a rich history spanning over a century, NREC College continues to provide top-tier instruction in Arts, Science, Commerce, and computing fields.'
                        ]
                    },
                    principalMessage: {
                        name: 'Dr. Principal Name',
                        designation: 'Principal',
                        quote: 'Education is the most powerful weapon which you can use to change the world.',
                        image: '/images/principal.png',
                        paragraphs: [
                            'It is my privilege to welcome you to NREC College. Our institution is dedicated to academic rigor, personal growth, and social responsibility.',
                            'We prepare our students to lead, innovate, and excel in a rapidly changing global landscape.'
                        ]
                    },
                    stats: [
                        { label: 'Students Enrolled', value: '5,000+' },
                        { label: 'Faculty Members', value: '150+' },
                        { label: 'Years of Legacy', value: '120+' },
                        { label: 'Academic Programs', value: '45+' }
                    ],
                    callToAction: {
                        title: 'Ready to Join Our Campus?',
                        subtitle: 'Admissions are open for the current academic session. Apply today to secure your future.',
                        stats: []
                    },
                    testimonials: [
                        {
                            name: 'Alumni Student',
                            role: 'BCA Batch of 2024',
                            quote: 'My years at NREC College were transformative. The faculty guided me every step of the way, helping me land a software engineering role.'
                        }
                    ]
                }
            });
            console.log('✅ Home page seeded');
        }
        console.log('🎉 Version 1.0 Seeding complete with rich sample data!');
        process.exit(0);
    }
    catch (error) {
        console.error('❌ Seeding failed:', error);
        process.exit(1);
    }
};
seed();
//# sourceMappingURL=seed.js.map