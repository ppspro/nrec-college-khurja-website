"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteCourse = exports.updateCourse = exports.createCourse = exports.getAllCoursesAdmin = exports.getCourseBySlug = exports.getCourses = void 0;
const Course_1 = __importDefault(require("../models/Course"));
const slugify_1 = __importDefault(require("slugify"));
const getCourses = async (req, res) => {
    try {
        const { department, level, featured } = req.query;
        const query = { isActive: true };
        if (department)
            query.department = department;
        if (level)
            query.level = level;
        if (featured === 'true')
            query.isFeatured = true;
        const courses = await Course_1.default.find(query).populate('department', 'name slug').sort({ order: 1, name: 1 });
        res.json({ success: true, courses });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getCourses = getCourses;
const getCourseBySlug = async (req, res) => {
    try {
        const course = await Course_1.default.findOne({ slug: req.params.slug, isActive: true }).populate('department', 'name slug');
        if (!course) {
            res.status(404).json({ success: false, message: 'Course not found' });
            return;
        }
        res.json({ success: true, course });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getCourseBySlug = getCourseBySlug;
const getAllCoursesAdmin = async (_req, res) => {
    try {
        const courses = await Course_1.default.find().populate('department', 'name').sort({ name: 1 });
        res.json({ success: true, courses });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.getAllCoursesAdmin = getAllCoursesAdmin;
const createCourse = async (req, res) => {
    try {
        const { name, code, department, level, type, duration, totalSeats, description, eligibility, feeStructure, syllabus, highlights, careerProspects, order, isFeatured } = req.body;
        const slug = (0, slugify_1.default)(name, { lower: true, strict: true });
        const course = await Course_1.default.create({
            name, slug, code, department, level, type, duration, totalSeats, description, eligibility, feeStructure, syllabus,
            highlights: highlights ? JSON.parse(highlights) : [],
            careerProspects: careerProspects ? JSON.parse(careerProspects) : [],
            order: order || 0,
            isFeatured: isFeatured === 'true',
        });
        res.status(201).json({ success: true, course });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.createCourse = createCourse;
const updateCourse = async (req, res) => {
    try {
        const updateData = { ...req.body };
        ['highlights', 'careerProspects'].forEach((key) => {
            if (updateData[key] && typeof updateData[key] === 'string') {
                updateData[key] = JSON.parse(updateData[key]);
            }
        });
        const course = await Course_1.default.findByIdAndUpdate(req.params.id, updateData, { new: true });
        if (!course) {
            res.status(404).json({ success: false, message: 'Course not found' });
            return;
        }
        res.json({ success: true, course });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.updateCourse = updateCourse;
const deleteCourse = async (req, res) => {
    try {
        const course = await Course_1.default.findByIdAndDelete(req.params.id);
        if (!course) {
            res.status(404).json({ success: false, message: 'Course not found' });
            return;
        }
        res.json({ success: true, message: 'Course deleted' });
    }
    catch (error) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
};
exports.deleteCourse = deleteCourse;
//# sourceMappingURL=courseController.js.map