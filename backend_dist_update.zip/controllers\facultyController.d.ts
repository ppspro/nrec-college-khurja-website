import { Request, Response } from 'express';
export declare const getFaculty: (req: Request, res: Response) => Promise<void>;
export declare const getFacultyById: (req: Request, res: Response) => Promise<void>;
export declare const getAllFacultyAdmin: (_req: Request, res: Response) => Promise<void>;
export declare const createFaculty: (req: Request, res: Response) => Promise<void>;
export declare const updateFaculty: (req: Request, res: Response) => Promise<void>;
export declare const deleteFaculty: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=facultyController.d.ts.map