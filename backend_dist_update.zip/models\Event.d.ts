import mongoose, { Document } from 'mongoose';
export interface IEvent extends Document {
    title: string;
    slug: string;
    description: string;
    content: string;
    image: string;
    venue: string;
    startDate: Date;
    endDate: Date;
    startTime: string;
    endTime: string;
    category: string;
    registrationLink: string;
    isPublished: boolean;
    isFeatured: boolean;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IEvent, {}, {}, {}, mongoose.Document<unknown, {}, IEvent, {}, {}> & IEvent & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
}, any>;
export default _default;
//# sourceMappingURL=Event.d.ts.map