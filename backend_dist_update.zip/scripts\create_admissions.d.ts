export {};
//# sourceMappingURL=create_admissions.d.ts.map