"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const mediaController_1 = require("../controllers/mediaController");
const auth_1 = require("../middleware/auth");
const upload_1 = require("../middleware/upload");
const router = (0, express_1.Router)();
router.get('/', auth_1.protect, mediaController_1.getMedia);
router.post('/', auth_1.protect, upload_1.upload.array('files', 10), mediaController_1.uploadMedia);
router.delete('/:id', auth_1.protect, mediaController_1.removeMedia);
exports.default = router;
//# sourceMappingURL=media.js.map